﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADataLogic.Master.LogicLayer
{
  internal  class LedgerMaster
    {
        public LedgerMaster()
        {
           
        }

    }
}
