﻿using api.ApiBusinessLogic.DatabaseModel;
using api.ApiBusinessLogic.Master.DynamicLayerData;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace api.ApiBusinessLogic.Master.BusinessLayerData
{


    //public class LedgerMasterBLL: LedgerMasterDLL
    //{
     

    //    private readonly LedgerMasterDLL _ledgerMasterDLL;

       

    //    public LedgerMasterBLL(LedgerMasterDLL ledgerMasterDLL, IConfiguration configuration) :base(configuration)
    //    {
    //        this._ledgerMasterDLL = ledgerMasterDLL;
    //    }


    //    //public ResultType getGeneralLegerList()
    //    //{
    //    //    return _ledgerMasterDLL.getGeneralLegerList();

    //    //}
    //}
   
}
