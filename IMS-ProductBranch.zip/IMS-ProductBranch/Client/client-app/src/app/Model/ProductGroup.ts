export class ProductGroup {
    prGroupCode? :number;
    prGrpDesc:string;
    prGrpShortName:string;
    prGroupLock ?:boolean;
    prGroupActive ?:boolean;

}