export class Customer{
    customerId:number;
    description:string;
    shortName:string;
    group:string;
    subGroup:string;
    category:string;
    country:string;
    city:string;
    emailAddress:string;
    address:string;
    conatactNo:string;

}