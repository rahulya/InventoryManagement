export class salesDetail{
    sb_InvNo ? :string ;
    sNO:number;
    p_Code:string;
    gdn:string;
    alt_Qty  :number ;
    alt_Unit:string;
    qty:number;
    unit:string;
    altStock_Qty:number;
    stockQty:number;
    rate:number;
    basic_Amt:number;
    term_Amt:number;
    net_Amt:number;
    add_desc:string;
    challan_No:string;
    sbOrder_No:string;
    order_Sno:string;
    sB_Free_Qty:number;
    sBStock_Free_Qty:number;
    free_Unit:string;
    sBConv_Ratio:number;
    cItem:string;
    billSys:string;
    sBDisOrder_no:string;
    sBDisOrder_Sno:number;
    sB_ExtraFree_Qty:number;
    sBStock_ExtraFree_Qty:number;
    extra_Free_Unit:string;
    taxPriceRate:number;
    taxGroupID:string;
    calculateTaxItem:string;
    taxInclusiveItem:string;
    billRateInclusive:string;
    remarks:string;
    
}
