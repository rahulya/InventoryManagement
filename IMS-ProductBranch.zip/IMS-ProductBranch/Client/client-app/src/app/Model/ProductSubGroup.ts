export class ProductSubGroup{
    prSubGrpCode ?:number;
    prSubGrpDesc:string;
    prGroupCode:number;
}