
export class  generalLedger{
    gl_Code ? :string ;
    gl_Desc:string;
    gl_ShortName:string;
    gl_Category:string;
    ac_GrpCode  :string ;
    ac_SGrpCode:string ;
    cash_Bank:string;
    cash_Book:string;
    subLedger:string;
    docAdjust:string;
    area_Code:string;
    agent_Code:string;
    credit_Limit:string;
    credit_Day:number;
    rate_Of_Intrest:number;
    gl_Adress:string;
    gl_City:string;
    gl_State:string;
    gl_Country:string;
    gl_Phone_Office:string;
    gl_Phone_Res:string;
    gl_Fax:string;
    gl_Email:string;
    gl_PanNo:string;
    contact_Person:string;
    cr_Code:string;
    scheme_Group_Id:number;
    turnOverAmt:string;
    glLock:string;
    temp_Gl_Code:string;
    tINNo:string;
    tANNo:string;
    serviceTaxNo:string;
    gSTNo:string;
    cSTNo:string;
    exciseRCNo:string;
    chequeRecDay:number;


    scheme_Code:string;
    source_Module:string;
    dL_No:string;
    bill_RateOn:string;
    class_Code:string;
    class_Code1:string;
    class_Code2:string;
    action_Date:Date;
    action_Time:Date;
    action_Miti:string;
    action:string;
    document_Date:string;
    creditBal:string;
    creditday:string;
    countryCode:string;
    mobileNo:string;
    mobileNo1:string;
    mobileNo2:string;
    bankGuarntee:string;
    cashDeposit:string;
    gl_Authorize_Type:string;

    gl_Authorize_Remarks:string;
    gl_Authorize_By:boolean;
    gl_Authorize_Date:Date;
    lReconcileDate:Date;
    ac_Desc:string;
    ac_SGrpDesc:string;
    agent_Desc:string;
    area_Desc:string;
    sno:string;
   

}
