export class Sales_BillingTerm_Master{
    
    sT_Code:string;
    sT_ShortName:string;
    sT_Desc:string;
    gl_Code:string;
    sT_Basis:string;
    st_ProductBasic:string;
    sT_Sign:string;
    sT_ProductWise:string;
    sT_Category:string;
    sT_Profibality:string;
    sT_Formula:string;
    sT_Rate:number;
    decimalType:string;
    sT_SupressZero:string;
    margin:string;

}